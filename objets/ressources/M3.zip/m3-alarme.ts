basic.forever(function () {
    if (input.temperature() > 30) {
        basic.showIcon(IconNames.Sad)
        music.playTone(262, music.beat(BeatFraction.Whole))
    } else {
        basic.showIcon(IconNames.Happy)
    }
})
