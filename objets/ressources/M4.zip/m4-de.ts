let de = 0
input.onGesture(Gesture.Shake, function () {
    de = randint(1, 6)
    basic.showNumber(de)
})
